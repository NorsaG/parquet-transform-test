(function (c) {
    function isEngineInited(attr) {
        return  document.querySelectorAll('[' + attr +']').length;
    }
				
    function insertScript(src, attr) {
        let script = document.createElement('script');
        script.type = 'text/javascript';
        script.async = 1;
        script.src = src;
        script.dataset[attr] = 'true';
				
        let head = document.getElementsByTagName('head')[0];
        head.insertBefore(script, head.firstChild);
    }
				
    if (c.isCoreEngineEnabled && !isEngineInited('data-roxot-core-inited')) {
        insertScript(c.coreEngineUrl, 'roxotCoreInited');
				
        window.rxtCore = window.rxtCore || {icmd: []};
        window.rxtCore.icmd = window.rxtCore.icmd || [];
        window.rxtCore.icmd.push(c.coreEngineSettings);
    }
				
    if (c.isEngineEnabled && !isEngineInited('data-roxot-ad-inited')) {
				
        insertScript(c.managerUrl, 'roxotAdInited');
				
        window.rom = window.rom || {cmd: [], icmd: []};
        window.rom.icmd = window.rom.icmd || [];
        window.rom.icmd.push(c);
    }
})({"adBlockMode":"iframe","coreEngineSettings":{"roxotYaMetric":{"enabled":false,"counterId":88477929},"roxotAdPixel":{"enabled":false,"pixels":[{"urlIncludes":"habr.com","pixelsUrls":["https:\/\/rap.skcrtxr.com\/pub\/pix\/f7e1a8da-c1c8-4bf4-9c07-20fb20d25136"]},{"urlIncludes":"https:\/\/habr.com\/ru\/feed\/","pixelsUrls":["https:\/\/rap.skcrtxr.com\/pub\/pix\/3c2d7d3e-197f-45bb-83e0-f1c9d992e42f"]},{"urlIncludes":"https:\/\/habr.com\/ru\/flows\/develop\/articles\/","pixelsUrls":["https:\/\/rap.skcrtxr.com\/pub\/pix\/3c2d7d3e-197f-45bb-83e0-f1c9d992e42f"]}]},"cpmGrid":[],"cpmGridUrl":"https:\/\/grid.skcrtxr.com\/c"},"coreEngineUrl":"https:\/\/cdn-c.skcrtxr.com\/wrapper\/js\/rp-core-engine.js?v=s-beb6d9ff-adb0-4c26-83ce-29ff4c54021a","dynamicUrlTemplate":"https:\/\/cdn.skcrtxr.com\/wrapper-builder\/c427193e-c45c-4b31-b9de-0d5bc41115fd\/dynamic.js?host=__HOST__\u0026v=d-1785337366__s-beb6d9ff-adb0-4c26-83ce-29ff4c54021a","geoSpecificUrl":"https:\/\/openrtb.skcrtxr.com\/def-g","gfsPlacementOptionsTemplate":"https:\/\/ad-pixel.ru\/wrapper-builder\/gfs-placement\/__PLACEMENT_ID__?v=d-1785337366","hostConfig":{"habr.com":{"wrapperOptions":[],"isAcceptableAdsEnabled":false}},"iframeSspList":["google","prebid","prebid_dfp"],"isBrowserSpecific":false,"isCoreEngineEnabled":false,"isDeviceTypeSpecific":false,"isEngineEnabled":true,"isGeoSpecific":true,"isGetParamSpecific":true,"isLanguageSpecific":true,"isOsSpecific":false,"lazyLoading":[],"managerUrl":"https:\/\/cdn-c.skcrtxr.com\/wrapper\/js\/common-engine.js?v=s-beb6d9ff-adb0-4c26-83ce-29ff4c54021a","monetizationStatsUrl":"https:\/\/worker.sttsmntz.ru\/stats\/format","openRtbApiGetUserInfoUrl":"https:\/\/skcrtxr.com\/open-rtb-api\/get-user-bidders-info","placementConfigTemplate":"https:\/\/cdn.skcrtxr.com\/wrapper-builder\/placement\/__PLACEMENT_ID__?v=d-1785337366","publisher":"TechMedia","publisherId":"c427193e-c45c-4b31-b9de-0d5bc41115fd","syncCookiesUrl":"https:\/\/csync.skcrtxr.com\/user-sync-api\/sync","wrapperConfig":{"syncThemes":{"enabled":true,"method":"chat_v2"},"monetizationStatsIntegration":{"enabled":true,"requestSettings":{"isNeedToSend":true,"sampleCoefficient":1},"impressionSettings":{"isNeedToSend":true,"sampleCoefficient":1},"visibleImpressionSettings":{"isNeedToSend":true,"sampleCoefficient":1},"urlSettings":{"isNeedToSend":true},"referrerSettings":{"isNeedToSend":true}},"host":"habr.com","engineFileName":"common-engine.js","enableAdFirstLoadInHiddenTab":true,"universalPlaceHolder":{"enabled":false},"prebid":{"prebidTimeout":1500,"adjustment":{"appnexus":0.95},"path":"https:\/\/cdn.skcrtxr.com\/wrapper\/js\/prebid.js?v=s-beb6d9ff-adb0-4c26-83ce-29ff4c54021a"},"adfox":{"integrationTitle":"Adfox Monetizationsuperman","hb":{"timeout":1000,"biddersMap":{"roxot":"3072417","betweenDigital":"1749489","myTarget":"1749495","otm":"1749502","segmento":"1749486","hybrid":"1749494","adriver":"1749497","buzzoola":"1749491","getintent":"1749562","videonow":"2349515","adfox_adsmart":"1935860","adfox_yandex_premium-publisher-network":"1952235","adfox_yandex_roxot-adfox-hb":"2293037","smi2":"3396567"}}},"roxotYaMetric":{"enabled":false,"counterId":88477929},"msYaMetric":{"enabled":false},"roxotAdPixel":{"enabled":false,"pixels":[{"urlIncludes":"habr.com","pixelsUrls":["https:\/\/rap.skcrtxr.com\/pub\/pix\/f7e1a8da-c1c8-4bf4-9c07-20fb20d25136"]},{"urlIncludes":"https:\/\/habr.com\/ru\/feed\/","pixelsUrls":["https:\/\/rap.skcrtxr.com\/pub\/pix\/3c2d7d3e-197f-45bb-83e0-f1c9d992e42f"]},{"urlIncludes":"https:\/\/habr.com\/ru\/flows\/develop\/articles\/","pixelsUrls":["https:\/\/rap.skcrtxr.com\/pub\/pix\/3c2d7d3e-197f-45bb-83e0-f1c9d992e42f"]}]},"videojsLibs":{"path":"https:\/\/cdn.skcrtxr.com\/wrapper\/js\/video-libs.js?v=s-beb6d9ff-adb0-4c26-83ce-29ff4c54021a"},"pageUrlVariableName":"roxotPlusPageUrl","stubVideoPath":"https:\/\/cdn.skcrtxr.com\/wrapper\/js\/video-ad?v=s-beb6d9ff-adb0-4c26-83ce-29ff4c54021a","adfoxIntegrationType":"direct","yandexIntegrationType":"common","openRtbHost":"https:\/\/openrtb.skcrtxr.com"}})